@if (Route::has('/'))
    <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
        @auth
            <a href="{{ route('logout') }}" class="text-sm text-gray-700 dark:text-gray-500 underline" style="float:right;text-decoration:underline">Logout</a>
        @else
        @endauth
    </div>
@endif
