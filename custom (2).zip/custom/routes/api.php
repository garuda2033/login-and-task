<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TaskController;
use App\Http\Controllers\Usercontroller;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:sanctum')->post('/',[Usercontroller::class,'register']);
route::post('/',[Usercontroller::class,'register']);
route::post('/add',[TaskController::class,'store']);
// Route::middleware('auth:sanctum')->post('/add',[TaskController::class,'store']);
Route::middleware('auth:sanctum')->get('/index',[TaskController::class,'index']);

// route::get('/',[TaskController::class,'index']);
route::get('/edit/{id}',[TaskController::class,'edit']);
Route::middleware('auth:sanctum')->put('/status/{id}',[TaskController::class,'update']);
route::delete('/delete/{id}',[TaskController::class,'delete']);
route::get('/search/{search}',[TaskController::class,'search']);
