<?php $__env->startSection('content'); ?>
<section class="vh-100 gradient-custom">
    <div class="container py-2 h-100">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col col-xl-9">
          <div class="card">
            <div class="card-body ">
                <h1>Add task</h1>
              <form  action="<?php echo e(url('todo/add')); ?>" method="post" class=" justify-content-center align-items-center ">
                <?php echo csrf_field(); ?>
                <div class="form-outline ">
                    <input type="text" name="user_id" class="form-control" required/>
                    <label class="form-label" >User id</label>
                  </div>
                <div class="form-outline ">
                  <input type="text" name="task" class="form-control" required />
                  <label class="form-label" >Add New task</label>
                </div>
                <button type="submit" class="btn btn-info float-right">Add</button>
              </form>
            </div>
          </div>

        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\custom\resources\views/createtask.blade.php ENDPATH**/ ?>