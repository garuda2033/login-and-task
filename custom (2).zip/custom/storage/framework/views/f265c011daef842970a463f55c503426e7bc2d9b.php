<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 offset-md-2 mx-auto">
                <div class="card form-holder">
                    <div class="card-body">
                        <h1>Login</h1>

                        <?php if(Session::has('error')): ?>
                            <p class="text-danger"><?php echo e(Session::get('error')); ?></p>
                        <?php endif; ?>
                        <?php if(Session::has('success')): ?>
                            <p class="text-success"><?php echo e(Session::get('success')); ?></p>
                        <?php endif; ?>

                        <form action="<?php echo e(url('/')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('post'); ?>
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" name="email" class="form-control" placeholder="Email" />
                                <?php if($errors->has('email')): ?>
                                    <p class="text-danger"><?php echo e($errors->first('email')); ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label>Password</label>
                                <input type="password" name="password" class="form-control" placeholder="Password" />
                                <?php if($errors->has('password')): ?>
                                    <p class="text-danger"><?php echo e($errors->first('password')); ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="row">
                                <div class="col-8 text-left">Need a account
                                    <a href="<?php echo e(route('register')); ?>" class="btn btn-link"><i style="text-decoration:underline ">Sign up</i></a>
                                                                 </div>
                                <div class="col-4 text-right">
                                    <input type="submit" class="btn btn-primary" value=" Login " />
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\custom\resources\views/auth/login.blade.php ENDPATH**/ ?>