<?php if(Route::has('/')): ?>
    <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
        <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(route('logout')); ?>" class="text-sm text-gray-700 dark:text-gray-500 underline" style="float:right;text-decoration:underline">Logout</a>
        <?php else: ?>
        <?php endif; ?>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\custom\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>