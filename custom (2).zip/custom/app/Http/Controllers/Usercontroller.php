<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
USE App\Models\User;
use Illuminate\Support\Facades\DB;

class Usercontroller extends Controller
{
    //
    public function register(Request $request){
        $request->validate([
            'name'=>'required',
            'email'=>'email|required',
            'password'=>'required',
        ]);
        $user=User::create([
            'name'=>$request->name,
            'email'=>$request->email,
            'password'=>$request->password,
        ]);
        $token=$user->createToken('ranjeet')->plainTextToken;
        return response([
            'success'=>'insert data successfully',
            'user'=>$user,
            'token'=>$token
        ],201);
    }
    public function index(){
        $data= DB::table('users')
              ->join('tables', 'users.id', '=', 'tables.id')
              ->get();
              return view('home',compact('data'));

    }
}
